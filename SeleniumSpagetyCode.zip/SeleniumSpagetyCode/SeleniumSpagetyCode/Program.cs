﻿namespace SeleniumSpagetyCode
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
