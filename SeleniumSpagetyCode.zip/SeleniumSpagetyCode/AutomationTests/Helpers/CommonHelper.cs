﻿using System;
using System.IO;
using System.Linq;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using AutomationTests.Constants;
using AutomationTests.Extentions;

namespace AutomationTests.Helpers
{
    public static class CommonHelper
    {
        public static IWebDriver Driver { get; set; }

        static CommonHelper()
        {
            Driver = PropertiesCollection.Driver;
        }

        public static void NavigateGmail()
        {
            Driver.Navigate().GoToUrl(AutomationTestsConstants.GmailAddres);
        }

        public static void GenerateFile(string path, uint bytes)
        {
            try
            {
                if (File.Exists(path))
                {
                    File.Delete(path);
                }

                using (FileStream fs = File.Create(path))
                {
                    for (uint i = 0; i < bytes; i++)
                    {
                        fs.WriteByte(1);
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }
        }

        public static void AcceptPopap()
        {
            try
            {
                Driver.SwitchTo().Alert().Accept();
            }
            catch (NoAlertPresentException) {}
        }
    }

}