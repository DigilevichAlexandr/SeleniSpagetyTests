﻿namespace AutomationTests.Models
{
    public class Letter
    {
        public string To { get; set; }
        public string Subject { get; set; }
        public string MessageBody { get; set; }
    }
}