﻿namespace AutomationTests.Models
{
    public class User
    {
        public string Address { get; set; }
        public string Password { get; set; }
    }
}