﻿using OpenQA.Selenium;

namespace AutomationTests
{
    public static class PropertiesCollection
    {
        public static IWebDriver Driver { get; set; }
    }
}