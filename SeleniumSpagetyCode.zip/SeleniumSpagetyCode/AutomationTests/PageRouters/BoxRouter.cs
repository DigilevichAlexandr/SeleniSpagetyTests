﻿using System;
using System.Linq;
using System.Linq.Expressions;
using System.Net.Mail;
using System.Threading;
using AutomationTests.Constants;
using AutomationTests.Extentions;
using AutomationTests.Helpers;
using AutomationTests.PageModels;
using AutomationTests.PageModels.Settings;
using OpenQA.Selenium;

namespace AutomationTests.PageRouters
{
    public class BoxRouter
    {
        private IWebDriver _driver;
        
        private BoxPageModel _boxPageModel;
        private ComposePageModel _composePageModel;
        private InboxPageModel _inboxPageModel;
        private SettingsRouter _settingsRouter;
        private ChooseAnAccountPageModel _chooseAnAccountPageModel;



        public BoxRouter()
        {
            _driver = PropertiesCollection.Driver;
            _boxPageModel = new BoxPageModel();
            _composePageModel = new ComposePageModel();
            _inboxPageModel = new InboxPageModel();
            _settingsRouter = new SettingsRouter();
            _chooseAnAccountPageModel = new ChooseAnAccountPageModel();
        }

        public void Logout()
        {
            NavigateChooseAnAccount();
            CommonHelper.AcceptPopap();
            _chooseAnAccountPageModel.SignOut.Click();
            var chooseButton = _driver.FindElements(By.Id("account-chooser-link"));
            if (chooseButton.Any())
            {
                chooseButton.First().Click();
            }
                
            _driver.FindElement(By.Id("account-chooser-add-account")).Click();
        }

        public void Forwarding()
        {
            NavigateSettings();
            _settingsRouter.NavigateForwarding();
        }

        public void Send(string to, string subject, string message)
        {
            _boxPageModel.ComposeButton.Click();
            _driver.Manage().Timeouts().ImplicitlyWait(TimeSpan.FromSeconds(10));
            _composePageModel.To.SendKeys(to);
            _composePageModel.Subject.SendKeys(subject);
            _composePageModel.MessageBody.SendKeys(message);

            _composePageModel.SendButton.Click();
            Thread.Sleep(5000);
        }

        public bool MessageIsInTrash(string name)
        {
            _driver.Navigate().GoToUrl("https://mail.google.com/mail/u/0/#trash");
            return
                _driver.FindElements(
                    By.XPath(
                        "//td[text()='No conversations in the Trash. Who needs to delete when you have so much storage?!']"))
                    .Count == 0
                && name.StartsWith(_driver.FindElement(By.XPath(AutomationTestsConstants.FirstItemName)).Text);
        }

        public bool MessageIsInInbox(string name)
        {
            _driver.Navigate().GoToUrl("https://mail.google.com/mail/u/0/#inbox");
            return
                _driver.FindElements(
                    By.XPath(
                        "//td[text()='Your Primary tab is empty.']"))
                    .Count == 0
                && name.StartsWith(_driver.FindElement(By.XPath(AutomationTestsConstants.IboxFirstItemName)).Text);
        }

        public bool MessageMarkedUsImportant()
        {
            // TO DO
            return true; 
        }

        public void NavigateSettings()
        {
            _driver.Navigate().GoToUrl(AutomationTestsConstants.SettingsUrl);
        }

        public void NavigateChooseAnAccount()
        {
            _driver.Navigate().GoToUrl(AutomationTestsConstants.ChoseAnAccountUrl);
        }
    }
}